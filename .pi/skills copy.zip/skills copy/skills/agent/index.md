---
title: "AI Coding Agents — Agent-Native Orchestrators & Codex Skills"
description: "25 agent-native orchestrators for Claude Code, Codex CLI, and Gemini CLI — multi-skill AI agents across engineering, product, marketing, and more."
---

<div class="domain-header" markdown>

# :material-robot: Agents

<p class="domain-count">25 agents that orchestrate skills across domains</p>

</div>

<div class="grid cards" markdown>

-   :material-trending-up:{ .lg .middle } **[Growth Strategist](cs-growth-strategist.md)**

    ---

    Business & Growth

-   :material-account-tie:{ .lg .middle } **[CEO Advisor Agent](cs-ceo-advisor.md)**

    ---

    C-Level Advisory

-   :material-account-tie:{ .lg .middle } **[CTO Advisor Agent](cs-cto-advisor.md)**

    ---

    C-Level Advisory

-   :material-rocket-launch:{ .lg .middle } **[Senior Engineer](cs-senior-engineer.md)**

    ---

    Engineering - POWERFUL

-   :material-code-braces:{ .lg .middle } **[Engineering Lead](cs-engineering-lead.md)**

    ---

    Engineering - Core

-   :material-code-braces:{ .lg .middle } **[Workspace Admin](cs-workspace-admin.md)**

    ---

    Engineering - Core

-   :material-calculator-variant:{ .lg .middle } **[Financial Analyst](cs-financial-analyst.md)**

    ---

    Finance

-   :material-bullhorn-outline:{ .lg .middle } **[Content Creator Agent](cs-content-creator.md)**

    ---

    Marketing

-   :material-bullhorn-outline:{ .lg .middle } **[Demand Generation Specialist Agent](cs-demand-gen-specialist.md)**

    ---

    Marketing

-   :material-account:{ .lg .middle } **[Persona-Based Agents](readme.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Agent Name Agent Personality](template.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Content Strategist](content-strategist.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[DevOps Engineer](devops-engineer.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Finance Lead](finance-lead.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Growth Marketer Agent Personality](growth-marketer.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Product Manager](product-manager.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Solo Founder Agent Personality](solo-founder.md)**

    ---

    Personas

-   :material-account:{ .lg .middle } **[Startup CTO Agent Personality](startup-cto.md)**

    ---

    Personas

-   :material-lightbulb-outline:{ .lg .middle } **[Agile Product Owner Agent](cs-agile-product-owner.md)**

    ---

    Product

-   :material-lightbulb-outline:{ .lg .middle } **[Product Analyst Agent](cs-product-analyst.md)**

    ---

    Product

-   :material-lightbulb-outline:{ .lg .middle } **[Product Manager Agent](cs-product-manager.md)**

    ---

    Product

-   :material-lightbulb-outline:{ .lg .middle } **[Product Strategist Agent](cs-product-strategist.md)**

    ---

    Product

-   :material-lightbulb-outline:{ .lg .middle } **[UX Researcher Agent](cs-ux-researcher.md)**

    ---

    Product

-   :material-clipboard-check-outline:{ .lg .middle } **[Project Manager Agent](cs-project-manager.md)**

    ---

    Project Management

-   :material-shield-check-outline:{ .lg .middle } **[Quality Regulatory](cs-quality-regulatory.md)**

    ---

    Regulatory & Quality

</div>

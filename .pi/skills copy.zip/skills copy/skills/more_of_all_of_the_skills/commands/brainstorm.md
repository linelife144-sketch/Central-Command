Use your brainstorming skill.
